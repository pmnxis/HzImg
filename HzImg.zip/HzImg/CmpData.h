#pragma once
#include "HzImg.h"

double MSEcmp(imgPot * src, imgPot * dst);
double PSNRcmp(imgPot * src, imgPot * dst);