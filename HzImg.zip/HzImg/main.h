﻿#pragma once
#include "HzImg.h"
#include "DFT.h"
#include "DCT.h"
#include "CmpData.h"

int main();