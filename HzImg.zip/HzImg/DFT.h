﻿#pragma once
#include "HzImg.h"

extern imgPot * ForwardDFT(imgPot * src);
extern imgPot * InverseDFT(imgPot * src);